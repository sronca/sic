module.exports = {
    testFiles: [
		'bower_components/jQuery/dist/jquery.min.js',
        'bower_components/angular/angular.js',
        'bower_components/angular-mocks/angular-mocks.js',
        'angular-recursion.min.js',
        'test/**/*.js'
    ]
};